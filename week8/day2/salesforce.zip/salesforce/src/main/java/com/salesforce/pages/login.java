package com.salesforce.pages;

import org.openqa.selenium.WebElement;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class login extends ProjectSpecificMethods{
	
	public login enterUname(String uName) {
		WebElement user = locateElement(Locators.XPATH,"//input[@id='username']");
		clearAndType(user, uName);
		reportStep("uname entered sucessfully","pass");
		return this;
	}
	public login enterPwd(String pwd) {
		
		clearAndType(locateElement("password"), pwd);
		reportStep("pwd entered sucessfully","pass");
		return this;
		
	}
	public Wecome clickLogin() {
		
		click(locateElement("Login"));
		reportStep("logged in sucessfully","pass");
		return new Wecome();
	
}

}

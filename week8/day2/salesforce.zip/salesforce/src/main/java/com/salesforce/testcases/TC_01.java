package com.salesforce.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.testng.api.base.ProjectSpecificMethods;
import com.salesforce.pages.login;

public class TC_01 extends ProjectSpecificMethods{
	@BeforeTest
	public void setValues() {
		excelFileName="login";
		testcaseName="login with valid credentials" ;
		testDescription="login scenario";
		authors="saran";
		category="sanity";
		
		
	}
	@Test(dataProvider="fetchData")
	public void runLogin(String uName,String pwd) {
		login lp=new login();
		lp.enterUname(uName).enterPwd(pwd).clickLogin();
		
	}

}
